﻿// -*- C++ -*-
// <rtc-template block="description">
/*!
 * @file  AngleDistanceExtractorRTC.cpp
 * @brief Angle Distance Extractor
 *
 */
// </rtc-template>

#include "AngleDistanceExtractorRTC.h"
#include <cmath>
#include <iostream>

// Module specification
// <rtc-template block="module_spec">
#if RTM_MAJOR_VERSION >= 2
static const char* const angledistanceextractorrtc_spec[] =
#else
static const char* angledistanceextractorrtc_spec[] =
#endif
  {
    "implementation_id", "AngleDistanceExtractorRTC",
    "type_name",         "AngleDistanceExtractorRTC",
    "description",       "Angle Distance Extractor",
    "version",           "1.0.0",
    "vendor",            "VenderName",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
AngleDistanceExtractorRTC::AngleDistanceExtractorRTC(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_angleIn("angle", m_angle),
    m_rangeIn("range", m_range),
    m_distanceOut("distance", m_distance)
    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
AngleDistanceExtractorRTC::~AngleDistanceExtractorRTC()
{
}



RTC::ReturnCode_t AngleDistanceExtractorRTC::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("angle", m_angleIn);
  addInPort("range", m_rangeIn);
  
  // Set OutPort buffer
  addOutPort("distance", m_distanceOut);

  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>

  
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t AngleDistanceExtractorRTC::onFinalize()
{
  return RTC::RTC_OK;
}
*/


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onStartup(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onShutdown(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onActivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onDeactivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


RTC::ReturnCode_t AngleDistanceExtractorRTC::onExecute(RTC::UniqueId ec_id)
{
    if (m_rangeIn.isNew()) {
        m_rangeIn.read();
    }

    double angle = 0.0;

    if (m_angleIn.isNew()) {
        m_angleIn.read();
        angle = m_angle.data;
    }

    
    double minA = m_range.config.minAngle;    // 起始角度
    double res = m_range.config.angularRes;  // 角度分辨率
    int index = static_cast<int>((angle - minA) / res + 0.5);

    if (index >= 0 && index < m_range.ranges.length()) {
        m_distance.data = m_range.ranges[index];
    }
    else {
        m_distance.data = -1; // 角度超出范围
    }
    setTimestamp(m_distance);
    m_distanceOut.write();

    // 在终端打印数据（调试用）
    std::cout << "Angle: " << angle << " deg, Distance: " << m_distance.data << " m" << std::endl;

    return RTC::RTC_OK;
    }
  




//RTC::ReturnCode_t AngleDistanceExtractorRTC::onAborting(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onError(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onReset(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onStateUpdate(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTC::onRateChanged(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}



extern "C"
{
 
  void AngleDistanceExtractorRTCInit(RTC::Manager* manager)
  {
    coil::Properties profile(angledistanceextractorrtc_spec);
    manager->registerFactory(profile,
                             RTC::Create<AngleDistanceExtractorRTC>,
                             RTC::Delete<AngleDistanceExtractorRTC>);
  }
  
}
