﻿// -*- C++ -*-
// <rtc-template block="description">
/*!
 * @file  AngleDistanceExtractorRTCTest.cpp
 * @brief Angle Distance Extractor (test code)
 *
 */
// </rtc-template>

#include "AngleDistanceExtractorRTCTest.h"

// Module specification
// <rtc-template block="module_spec">
#if RTM_MAJOR_VERSION >= 2
static const char* const angledistanceextractorrtc_spec[] =
#else
static const char* angledistanceextractorrtc_spec[] =
#endif
  {
    "implementation_id", "AngleDistanceExtractorRTCTest",
    "type_name",         "AngleDistanceExtractorRTCTest",
    "description",       "Angle Distance Extractor",
    "version",           "1.0.0",
    "vendor",            "VenderName",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
AngleDistanceExtractorRTCTest::AngleDistanceExtractorRTCTest(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_angleOut("angle", m_angle),
    m_rangeOut("range", m_range),
    m_distanceIn("distance", m_distance)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
AngleDistanceExtractorRTCTest::~AngleDistanceExtractorRTCTest()
{
}



RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("distance", m_distanceIn);
  
  // Set OutPort buffer
  addOutPort("angle", m_angleOut);
  addOutPort("range", m_rangeOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>
  
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onFinalize()
{
  return RTC::RTC_OK;
}
*/


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onStartup(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onShutdown(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onActivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onDeactivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onExecute(RTC::UniqueId /*ec_id*/)
{
  return RTC::RTC_OK;
}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onAborting(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onError(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onReset(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onStateUpdate(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t AngleDistanceExtractorRTCTest::onRateChanged(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


bool AngleDistanceExtractorRTCTest::runTest()
{
    return true;
}


extern "C"
{
 
  void AngleDistanceExtractorRTCTestInit(RTC::Manager* manager)
  {
    coil::Properties profile(angledistanceextractorrtc_spec);
    manager->registerFactory(profile,
                             RTC::Create<AngleDistanceExtractorRTCTest>,
                             RTC::Delete<AngleDistanceExtractorRTCTest>);
  }
  
}
