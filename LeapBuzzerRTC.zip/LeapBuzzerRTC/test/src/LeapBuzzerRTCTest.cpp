﻿// -*- C++ -*-
// <rtc-template block="description">
/*!
 * @file  LeapBuzzerRTCTest.cpp
 * @brief Leapmotion to Buzzer (test code)
 *
 */
// </rtc-template>

#include "LeapBuzzerRTCTest.h"

// Module specification
// <rtc-template block="module_spec">
#if RTM_MAJOR_VERSION >= 2
static const char* const leapbuzzerrtc_spec[] =
#else
static const char* leapbuzzerrtc_spec[] =
#endif
  {
    "implementation_id", "LeapBuzzerRTCTest",
    "type_name",         "LeapBuzzerRTCTest",
    "description",       "Leapmotion to Buzzer",
    "version",           "1.0.0",
    "vendor",            "VenderName",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
LeapBuzzerRTCTest::LeapBuzzerRTCTest(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_inOut("in", m_in),
    m_outIn("out", m_out)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
LeapBuzzerRTCTest::~LeapBuzzerRTCTest()
{
}



RTC::ReturnCode_t LeapBuzzerRTCTest::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("out", m_outIn);
  
  // Set OutPort buffer
  addOutPort("in", m_inOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>
  
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t LeapBuzzerRTCTest::onFinalize()
{
  return RTC::RTC_OK;
}
*/


//RTC::ReturnCode_t LeapBuzzerRTCTest::onStartup(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onShutdown(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onActivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onDeactivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


RTC::ReturnCode_t LeapBuzzerRTCTest::onExecute(RTC::UniqueId /*ec_id*/)
{
  return RTC::RTC_OK;
}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onAborting(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onError(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onReset(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onStateUpdate(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTCTest::onRateChanged(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


bool LeapBuzzerRTCTest::runTest()
{
    return true;
}


extern "C"
{
 
  void LeapBuzzerRTCTestInit(RTC::Manager* manager)
  {
    coil::Properties profile(leapbuzzerrtc_spec);
    manager->registerFactory(profile,
                             RTC::Create<LeapBuzzerRTCTest>,
                             RTC::Delete<LeapBuzzerRTCTest>);
  }
  
}
