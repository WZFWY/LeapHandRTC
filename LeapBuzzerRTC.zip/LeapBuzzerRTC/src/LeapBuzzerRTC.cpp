﻿// -*- C++ -*-
// <rtc-template block="description">
/*!
 * @file  LeapBuzzerRTC.cpp
 * @brief Leapmotion to Buzzer
 *
 */
// </rtc-template>

#include "LeapBuzzerRTC.h"

// Module specification
// <rtc-template block="module_spec">
#if RTM_MAJOR_VERSION >= 2
static const char* const leapbuzzerrtc_spec[] =
#else
static const char* leapbuzzerrtc_spec[] =
#endif
  {
    "implementation_id", "LeapBuzzerRTC",
    "type_name",         "LeapBuzzerRTC",
    "description",       "Leapmotion to Buzzer",
    "version",           "1.0.0",
    "vendor",            "VenderName",
    "category",          "Category",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
LeapBuzzerRTC::LeapBuzzerRTC(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_inIn("in", m_in),
    m_outOut("out", m_out),
    m_lastValue(false)   // 初始化为 false
    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
LeapBuzzerRTC::~LeapBuzzerRTC()
{
}



RTC::ReturnCode_t LeapBuzzerRTC::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("in", m_inIn);
  
  // Set OutPort buffer
  addOutPort("out", m_outOut);

  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>

  
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t LeapBuzzerRTC::onFinalize()
{
  return RTC::RTC_OK;
}
*/


//RTC::ReturnCode_t LeapBuzzerRTC::onStartup(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onShutdown(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onActivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onDeactivated(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


RTC::ReturnCode_t LeapBuzzerRTC::onExecute(RTC::UniqueId /*ec_id*/)
{
    if (m_inIn.isNew()) {
        m_inIn.read();

        if (m_in.data != m_lastValue) {
            std::cout << "[LeapBuzzerRTC] State changed: " << m_lastValue << " -> " << m_in.data << std::endl;
            // 发生变化：触发蜂鸣器
            m_out.data = 1000;  // 1000Hz
            setTimestamp(m_out);
            m_outOut.write();

            std::this_thread::sleep_for(std::chrono::milliseconds(300)); // 响0.3秒

            m_out.data = 0;
            setTimestamp(m_out);
            m_outOut.write();

            // 更新上次值
            m_lastValue = m_in.data;
        }
    }
  return RTC::RTC_OK;
}


//RTC::ReturnCode_t LeapBuzzerRTC::onAborting(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onError(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onReset(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onStateUpdate(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}


//RTC::ReturnCode_t LeapBuzzerRTC::onRateChanged(RTC::UniqueId /*ec_id*/)
//{
//  return RTC::RTC_OK;
//}



extern "C"
{
 
  void LeapBuzzerRTCInit(RTC::Manager* manager)
  {
    coil::Properties profile(leapbuzzerrtc_spec);
    manager->registerFactory(profile,
                             RTC::Create<LeapBuzzerRTC>,
                             RTC::Delete<LeapBuzzerRTC>);
  }
  
}
